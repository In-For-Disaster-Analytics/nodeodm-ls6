node generateSwaggerAPI.js
java -jar swagger2markup-cli-1.0.1.jar convert -i swagger.json -f index
