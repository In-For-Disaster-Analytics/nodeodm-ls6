****************************************
PLEASE REMOVE THIS NOTE AFTER READING IT!

First of all, thank you for taking the time to report an issue.

For questions, comments and feature requests, please open a topic on https://community.opendronemap.org/. This is not the right place.

Please open an issue only to report faults and bugs and follow the format specified below.
****************************************

### What is the problem?

[Type answer here]

### What should be the expected behavior?

[Type answer here]

### How can we reproduce this? (What steps did you do to trigger the problem? Be detailed)

[Type answer here]
